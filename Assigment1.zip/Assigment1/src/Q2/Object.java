package Q2;

public class Object {

    public static String InEqu(int n, int[][] forces) {

        int Sum_X = 0; int Sum_Y = 0; int Sum_Z = 0;

        for (int i = 0; i < n; i++) {
            Sum_X += forces[i][0];
            Sum_Y += forces[i][1];
            Sum_Z += forces[i][2];
        }
        if (Sum_X == 0 && Sum_Y == 0 && Sum_Z == 0) {
            System.out.println("YES");
            return "YES";
        } else {
            System.out.println("NO");
            return "NO";
        }
    }
}
