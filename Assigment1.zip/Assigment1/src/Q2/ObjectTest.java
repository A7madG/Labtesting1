package Q2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import static org.junit.Assert.*;
import org.junit.Test;

public class ObjectTest {

    @Test
    public void test1() {
        Scanner context = null;
        try {
            context = new Scanner(new File("C:\\Users\\rabia\\OneDrive\\Desktop\\Assigment1\\src\\Q2\\test1.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int [][] coordinates = new int [100][3];
        int i = 0;
        int n = context.nextInt();
        while(context.hasNextInt())
        {
            coordinates[i][0] = context.nextInt();
            coordinates[i][1] = context.nextInt();
            coordinates[i][2] = context.nextInt();
            i++;
        }
        assertTrue (Object.InEqu(n,coordinates) == "NO");
    }
    @Test
    public void test2() {
        Scanner context = null;
        try {
            context = new Scanner(new File("C:\\Users\\rabia\\OneDrive\\Desktop\\Assigment1\\src\\Q2\\test2.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int [][] coordinates = new int [100][3];
        int i = 0;
        int n = context.nextInt();
        while(context.hasNextInt())
        {
            coordinates[i][0] = context.nextInt();
            coordinates[i][1] = context.nextInt();
            coordinates[i][2] = context.nextInt();
            i++;
        }
        assertTrue (Object.InEqu(n,coordinates) == "YES");
    }
    @Test
    public void test3() {
        Scanner context = null;
        try {
            context = new Scanner(new File("C:\\Users\\rabia\\OneDrive\\Desktop\\Assigment1\\src\\Q2\\test3.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int [][] coordinates = new int [100][3];
        int i = 0;
        int n = context.nextInt();
        while(context.hasNextInt())
        {
            coordinates[i][0] = context.nextInt();
            coordinates[i][1] = context.nextInt();
            coordinates[i][2] = context.nextInt();
            i++;
        }
        assertTrue (Object.InEqu(n,coordinates) == "YES");
    }
    @Test
    public void test4() {
        Scanner context = null;
        try {
            context = new Scanner(new File("C:\\Users\\rabia\\OneDrive\\Desktop\\Assigment1\\src\\Q2\\test4.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int [][] coordinates = new int [100][3];
        int i = 0;
        int n = context.nextInt();
        while(context.hasNextInt())
        {
            coordinates[i][0] = context.nextInt();
            coordinates[i][1] = context.nextInt();
            coordinates[i][2] = context.nextInt();
            i++;
        }
        assertTrue (Object.InEqu(n,coordinates) == "NO");
    }
}
